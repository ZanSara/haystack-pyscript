from haystack.nodes.sampler.base import BaseSampler
from haystack.nodes.sampler.top_p_sampler import TopPSampler
