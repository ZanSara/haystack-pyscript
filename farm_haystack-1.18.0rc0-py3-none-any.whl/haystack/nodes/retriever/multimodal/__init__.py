from haystack.nodes.retriever.multimodal.retriever import MultiModalRetriever
from haystack.nodes.retriever.multimodal.embedder import MultiModalEmbedder
