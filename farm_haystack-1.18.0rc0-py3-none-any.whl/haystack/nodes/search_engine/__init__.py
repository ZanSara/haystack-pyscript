from haystack.nodes.search_engine.base import SearchEngine
from haystack.nodes.search_engine.web import WebSearch
