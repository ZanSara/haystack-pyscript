from haystack.nodes.audio.whisper_transcriber import WhisperTranscriber, WhisperModel
