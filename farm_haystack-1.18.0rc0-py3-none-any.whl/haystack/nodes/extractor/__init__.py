from haystack.nodes.extractor.entity import EntityExtractor, simplify_ner_for_qa
