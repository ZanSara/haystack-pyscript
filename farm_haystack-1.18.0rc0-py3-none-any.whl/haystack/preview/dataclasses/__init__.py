from haystack.preview.dataclasses.document import Document
